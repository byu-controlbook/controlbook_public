% single link arm - parameter file
addpath ./.. % adds the parent directory to the path
armParam % general arm parameters
