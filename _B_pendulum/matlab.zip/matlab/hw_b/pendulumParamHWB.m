% inverted pendulum - parameter file for hw8
addpath ./.. % adds the parent directory to the path
pendulumParam % general pendulum parameters
