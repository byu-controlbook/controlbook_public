% inverted pendulum - parameter file
addpath ./.. % adds the parent directory to the path
pendulumParam % general pendulum parameters
