% inverted Pendulum parameter file

% Compute inner and outer open-loop transfer functions
P_in = tf([-2/P.m2/P.ell],[1,0,-2*(P.m1+P.m2)*P.g/P.m2/P.ell]);
P_out = tf([P.g],[1,0,0]);

