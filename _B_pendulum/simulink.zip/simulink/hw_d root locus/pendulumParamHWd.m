% inverted Pendulum parameter file

% dirty derivative parameters
P.sigma = 0.01; % cutoff freq for dirty derivative
P.beta = (2*P.sigma-P.Ts)/(2*P.sigma+P.Ts); % dirty derivative gain

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       PD Control: Time Design Strategy
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% tuning parameters
tr_th   = 0.5;        % Rise time for inner loop (theta)
zeta_th = 0.7;       % Damping Coefficient for inner loop (theta)
% M       = 10.0;        % Time scale separation between inner and outer loop
% zeta_z  = 0.7;       % Damping Coefficient fop outer loop (z)

% saturation limits
P.F_max = 5;                   % Max Force, N
error_max = 1;        		   % Max step size,m
theta_max = 30.0*pi/180.0;  % Max theta, rads

%---------------------------------------------------
%                    Inner Loop
%---------------------------------------------------
% parameters of the open loop transfer function
b0_th = -2.0/(P.m2*P.ell);
a1_th = 0.0;
a0_th = -2.0*(P.m1+P.m2)*P.g/(P.m2*P.ell);
% Desired natural frequency
wn_th = 2.2/tr_th;     
% coefficients for desired inner loop
% Delta_des(s) = s^2 + alpha1*s + alpha0 = s^2 + 2*zeta*wn*s + wn^2
alpha1_th = 2.0*zeta_th*wn_th;
alpha0_th = wn_th^2;

% compute gains
% Delta(s) = s^2 + (a1 + b0*kd)*s + (a0 + b0*kp)
P.kp_th = (alpha0_th-a0_th)/b0_th;
P.kd_th = (alpha1_th-a1_th)/b0_th;
DC_gain = P.kp_th/((P.m1+P.m2)*P.g+P.kp_th);

%---------------------------------------------------
%                    Outer Loop
%---------------------------------------------------
% parameters of the open loop transfer function
% b0_z = (P.m1*P.g/P.m2);
% a1_z = P.b/P.m2;
% a0_z = 0;
% 
% coefficients for desired outer loop
% Delta_des(s) = s^2 + alpha1*s + alpha0 = s^2 + 2*zeta*wn*s + wn^2
% tr_z = M*tr_th;   % desired rise time, s
% wn_z = 2.2/tr_z;  % desired natural frequency
% alpha1_z = 2.0*zeta_z*wn_z;
% alpha0_z = wn_z^2;
% 
% % compute gains
% % Delta(s) = s^2 + (a1 + b0*kd*DC_gain)*s + (a0 + b0*kp*DC_gain)
% P.kp_z = (alpha0_z-a0_z)/(DC_gain*b0_z);
% P.kd_z = (alpha1_z-a1_z)/(DC_gain*b0_z);
% 
% sprintf('DC_gain: %f\nkp_th: %f\nkd_th: %f\nkp_z: %f\nkd_z: %f\n',...
%     DC_gain, P.kp_th, P.kd_th, P.kp_z, P.kd_z)

% McLain stuff
if 1
    %PD design for outer loop
%     wn_z     = 2.2/tr_z; % natural frequency for outer loop
    a = 0.33; % zero location corresponding to kp_z/kd_z;
    
    bth = 2/(P.m2*P.ell);
    ath = (P.m1+P.m2)*P.g*bth;
    
    th_cl = tf(-bth*P.kp_th,[1 -bth*P.kd_th -(ath+bth*P.kp_th)])

%     D = tf([1 a],1);
    D = tf([1 a],[P.sigma 1]);
    G = th_cl*tf(-[P.ell/2 0 -P.g],[1 0 0]);
%     G = DC_gain*tf(-[P.ell/2 0 -P.g],[1 0 0]);
    figure(3); clf;
    rlocus(D*G); hold on;
    P.kd_z = 0.02;
    rlocus(D*G,P.kd_z,'x');

    % From root locus
    P.kp_z = P.kd_z*a;
end

