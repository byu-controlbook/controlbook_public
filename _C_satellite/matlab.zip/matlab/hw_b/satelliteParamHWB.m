% satellite - parameter file
addpath ./.. % adds the parent directory to the path
satelliteParam % general parameters
